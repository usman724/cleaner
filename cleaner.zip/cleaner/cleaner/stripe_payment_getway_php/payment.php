<?php
error_reporting(1);
session_start();

require 'stripe/Stripe.php';

$publishable_key 	= "pk_test_51HWlM0Ih3pbcutMOjr7l23eOF3dsMvkr6CywrX0AAeSwUp66GAu21VgbB8Tr9rwN7Up514zAlifzbbWmOkpsOM8u00MNIGDyLt";
$secret_key			= "sk_test_51HWlM0Ih3pbcutMO1quyitiA3V8lvljabBpFNC5rIHt1SxMXjmnompeBy6WmLe6ncIV09pjW9seE3dG24aZLuDWd00OkU9gkg1";

if(isset($_POST['stripeToken'])){
	Stripe::setApiKey($secret_key);
	$description 	= "Invoice #".rand(99999,999999999);
	$amount_cents 	= 100;
	$tokenid		= $_POST['stripeToken'];
	
	try {
		$charge 		= Stripe_Charge::create(array( 
		"amount" 		=> $amount_cents,
		"currency" 		=> "usd",
		"source" 		=> $tokenid,
		"description" 	=> $description)			  
		);
		
		$id			= $charge['id'];
		$amount 	= $charge['amount'];
        $balance_transaction = $charge['balance_transaction'];
        $currency 	= $charge['currency'];
        $status 	= $charge['status'];
        $date 	= date("Y-m-d H:i:s");
		
		$result = "succeeded";
		
		/* You can save the above response in DB */
		header("location:index.php?id=".$id);
		exit;

		}catch(Stripe_CardError $e) {			
			$error = $e->getMessage();
			$result = "declined";
		}
}

?>
<!doctype html>
<html lang="en">
 <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Epilogue:wght@300&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Responsive styles-->
<link rel="stylesheet" href="css/demo-style.css"> 
<!-- Font awosome -->
<link rel="stylesheet" href="css/font-awesome.min.css">  
 </head>
  <body >
 
<style type="text/css">
	*{ 
		box-sizing: border-box;
		margin: 0px;
        font-family: 'Epilogue', sans-serif;



	}
    textarea:hover, 
input:hover, 
textarea:active, 
input:active, 
textarea:focus, 
input:focus,
button:focus,
button:active,
button:hover,
label:focus,
.btn:active,
.btn.active
{
    outline:0px !important;
    -webkit-appearance:none;
    box-shadow: none !important;
}      .btn-warning {
    color: #ffffff;
    background-color: #ffc107c2;
    border-color: #ffc107;
}
    .btn{
        font-weight:700;
    }
    .btn-outline-primary{
        color:grey;
        border:1px solid grey;
    }
	/* width */
::-webkit-scrollbar {
  width: 8px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
  opacity: 0.5;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
    opacity: 0.5;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
    opacity: 0.5;
}



	body{
		background-color: #fff;
		height:100vh;
		overflow: hidden;
		max-height: 100vh;

	}

	  .cardleft{
	  	box-sizing: border-box;
		position: relative;
		background-color: #fff;
		width: 99vw;
		height: 88vh;
		max-height:89vh; 
		padding: 5px;
		margin: auto;
		overflow-x: hidden;
		overflow-y: auto;
		border: none;

	
	}


	.lgscreenbtn{
		display: none;
	}

	.smallscreenbtn{
		display: inline-flex;
		z-index: 1;
	}

	#outerbox{
	background-color: transparent;
    max-height: 83vh;
    overflow-x: hidden;
    overflow-y: auto;

	}

	#showonmobilescreen{
		display: none;
	}

	.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(2vw + 9px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(3vw + 20px);
		}
			
		
			@media only screen and (max-width: 373px) {
				.smallscreenmargin{
					margin-top: -10px
				}
				.smallscreenmarginlefr{
					margin-left: -30px;
				}

			}


	@media only screen and (min-width: 1021px) {

		#outerbox{
	background-color: transparent;
    max-height: 110vh;


	}
		
	  .cardleft{
		padding: 10px;
		background-color: #fff;
		margin-left:10vw;
		width: 38vw;
		height: 100vh;
		max-height:600px;
		box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); 
		border-radius:5px;
		overflow-x: hidden;
		overflow-y: auto;
		float: left;

		}

		.lgscreenbtn{
		display: inline-flex;
	}
		.smallscreenbtn{
			display: none;
		}

		.scrollview{
			max-height: 100%;
			overflow-y: auto;
		}


		#crossicon{
			display: none;
		}

		.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(1vw + 0px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(1vw + 1px);
		}
			body{
		background-color: #f4fcff;
		height:100vh;
		overflow: auto;
		max-height: 100vh;
		overflow-x: hidden;

		}

		#showonmobilescreen{
				display: block;
				float:right;
				width:28vw;
				margin-right:21vw;
                box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); 
			}
				
			#showonmobilescreen2{
				display: none;
			}
		
	}

</style>

<!-- Radio button design -->

<style>
/* The checkboxcontainer */
.checkboxcontainer {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.checkboxcontainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;

  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.checkboxcontainer:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.checkboxcontainer input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.checkboxcontainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.checkboxcontainer .checkmark:after {	
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}

.navbar-light .navbar-brand {
    color: orange;
    font-weight: bolder;
}

</style>
<nav class="navbar  navbar-light bg-dark" style="border-bottom:1px  solid grey;height: 8vh;">
  <a class="navbar-brand active" href="#">
  	Liza Maid
  </a>
 
</nav>








	<div id="outerbox" >
		<!-- Here location div -->


		<!-- <div class="locationdiv">
			<div class="row">
				<div class="col-md-12 text-center">
					<i class="fa fa-map-marker" style="font-size: 2rem;margin-top:10px;color:orange;opacity:0.9;  " aria-hidden="true">
						
					</i>
					Dubai Marina, Dubai

				</div>
			</div>
		</div>

		 End location div -->

		<!-- Here page title -->
		<!-- <div class="titlediv">
			<div class="row">
				<div class="col-md-12 text-center mt-3">
				
				<h4>Service detail</h4>

				</div>
			</div>
		</div> --> 
		<!-- End page title -->
        
        <style>
            .btn-primary{
                background:#54caff;
                border:none;
                font-size: 1rem;
   
                
            }
            .btn-primary:hover{
                background:#54caff;
                border:none;
                
            }

            .btn-primary:active{
                background:#54caff;
                border:none;
                
            }


            .btn-outline-primary:hover{
                background:#54caff;
                border:none;
            }
            .btn-outline-primary:active{
                background:#54caff;
                border:none;
            }
         </style>   

		<div class="whole pt-5" >
				
				<div class="cardleft card"  >
					<div class="row">
                    <div class="bg_area_1">
 		    <div class="container">  
                <div class="row">
                    <div class=" login-form-3 "> 
                       
                         
                        <div >
                            <div > 
                              <form action="" method="post" name="cardpayment" id="payment-form">
								<?php 
								if($_GET['id']!=""){
								?>
								<div class="form-group">
                                  <div class="payment-success">Thanks for your payment. <br/> Your Transaction Id: <?php print $_GET['id']?></div>
                                </div>
								<?php } ?>
								
                                <div class="form-group">
                                  <label class="form-label" for="name">Card Holder Name</label>
                                  <input name="holdername" id="name" class="form-input" type="text"  required />
                                  <i class="fa fa-user" aria-hidden="true"></i>
                                </div>
                                
                                <div class="form-group">
                                  <label class="form-label" for="email">Email</label>
                                  <input name="email" id="email" class="form-input" type="email" required />
                                 <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
								
								<div class="form-group">
                                  <label class="form-label" for="card">Card Number</label>
                                  <input name="cardnumber" id="card" class="form-input" type="text" maxlength="16" data-stripe="number" required />
                                 <i class="fa fa-credit-card-alt" aria-hidden="true"></i>
                                </div>


                                <div class="form-group2">
                                  <label class="form-label" for="password">Expiry Month / Year & CVV</label>
								  <select name="month" id="month" class="form-input2" data-stripe="exp_month">
									<option value="01">01</option>
									<option value="02">02</option>
									<option value="03">03</option>
									<option value="04">04</option>
									<option value="05">05</option>
									<option value="06">06</option>
									<option value="07">07</option>
									<option value="08">08</option>
									<option value="09">09</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
								</select>
								
								<select name="year" id="year" class="form-input2" data-stripe="exp_year">
									<option value="19">2019</option>
									<option value="20">2020</option>
									<option value="21">2021</option>
									<option value="22">2022</option>
									<option value="23">2023</option>
									<option value="24">2024</option>
									<option value="25">2025</option>
									<option value="26">2026</option>
									<option value="27">2027</option>
									<option value="28">2028</option>
									<option value="29">2029</option>
									<option value="30">2030</option>
								</select>
								
								<input name="cvv" id="cvv" class="form-input2" type="text" placeholder="CVV" data-stripe="cvc" required />
							
                                  <i class="fa fa-calendar" aria-hidden="true"></i>
                                </div>

								<div class="form-group">
                                  <div class="payment-errors"></div>
                                </div>

                                <div class="button-style">
                                    <button class="button login submit">
                                       Paynow ($1.00) <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                    </button>
                                </div>
                                
                              </form>
                            </div>
                        </div>  
                        
                    </div>
                </div> 
            </div> 
 		</div> 	
					</div>
					
				
						<div class="row lgscreenbtn" style="position: absolute;bottom: 0;border-top: 1px solid grey ;width: 100%;background-color: #fff;">
						<div class="col-md-12 p-3">
							<button type="button"  data-toggle="modal" data-target="#exampleModalCenter" class="btn btn-warning   float-right" style="width:150px;border-radius:20px; outline: none;
							">
								Next
							</button>
						</div>
					</div>
				</div>
				
				<div id="showonmobilescreen">
					
					<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1);border-bottom:3px solid grey; ">

					

						 <div class="card-body" style="border-bottom:1px solid #80808057;display: flex;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">City</h6>
						 	<h6>Dubai</h6>
						  </div>
						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
						 	<h6 id="materialchip">Yes</h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
                             <h6 id="dandt"></h6>
                             <span id="time1"></span>
						  </div>
						   </div>
<!-- Herer all rerocd -->
<input  name="location"  value="<?php echo($_GET['location']); ?>" style="display:none;"/>
 <input  name="booking"   value="<?php echo($_GET['booking']); ?>" style="display:none;"/>
 <input  name="cleaner"  value="<?php echo($_GET['cleaner']); ?>" style="display:none;"/>
 <input  name="material"   value="<?php echo($_GET['material']); ?>"style="display:none;"/>
 <input  name="duration"  value="<?php echo($_GET['duration']); ?>" style="display:none;"/>
<!-- end -->

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Address </h6>
						 	<h6><?php echo($_GET['location']) ?></h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
						 	<h6 id="materialchip"><?php echo($_GET['material']); ?></h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>
					</div>
				</div>


		</div>




	</div>

	<div id="showonmobilescreen2" style="overflow-y:auto;">
					
					<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					<div id="crossicon"  style="display: flex;justify-content: flex-end;margin:14px;margin-right:30px;  ">
                    <i   onclick="closediv()"  class="fa fa-times" aria-hidden="true">	
                        </i>
                        
					</div>

							<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					

						 <div class="card-body" style="border-bottom:1px solid #80808057;display: flex;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">City</h6>
						 	<h6>Dubai</h6>
						  </div>
						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
                                       <h6 id="materialchip"><?php echo($_GET['material']); ?></h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
                             <h6 id="dandt2"></h6>
                             <span id="time2"></span>
						  </div>
						   </div>


						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Address </h6>
						 	<h6><?php echo($_GET['location']) ?></h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
                                       <h6 id="materialchip"><?php echo($_GET['material']); ?></h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>
					</div>				
					</div>
				</div>
					<style type="text/css">
						#removefocus{
							background: none;
						}
						#removefocus:focus{
							outline: none;
						}
					</style>
					<div class="row smallscreenbtn" 
					style="position: fixed;bottom: 0;border-top: 1px solid grey ;width:102vw;
						background-color: #fff;max-height:100px; 
					">
							<div class="col-md-12 p-3" style="display: flex;justify-content: space-between;">



									<i  onclick="opencar();" class="fa fa-arrow" id="removefocus" style="width:150px;border-radius:20px; padding:5px 4px;
									font-size:24px;color:black;text-align: left; padding-left:2.5rem; 
									outline: none;border:none;

								  ">
									&#xf106;	

								</i>

							<button type="button"  data-toggle="modal" data-target="#exampleModalCenter"  class="btn btn-warning   float-right" style="width:150px;border-radius:20px; padding:5px 4px;
							color: white;font-size:18px;
							  ">
								Next
							</button>
						</div>
					</div>

                        





    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <!-- Footer -->
<footer class="page-footer font-small cyan darken-3" style="margin-top:120px;background-color: red;display: none;">

  <!-- Footer Elements -->
  <div class="container">

    <!-- Grid row-->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-12 py-5">
        <div class="mb-5 flex-center">

          <!-- Facebook -->
          <a class="fb-ic">
            <i class="fab fa-facebook-f fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic">
            <i class="fab fa-twitter fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
          </a>
          <!-- Google +-->
          <a class="gplus-ic">
            <i class="fab fa-google-plus-g fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic">
            <i class="fab fa-linkedin-in fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic">
            <i class="fab fa-instagram fa-lg white-text mr-md-5 mr-3 fa-2x"> </i>
          </a>
          <!--Pinterest-->
          <a class="pin-ic">
            <i class="fab fa-pinterest fa-lg white-text fa-2x"> </i>
          </a>
        </div>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->

  </div>
  <!-- Footer Elements -->
  </form>
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://mdbootstrap.com/"> MDBootstrap.com</a>
  </div>


  <!-- Copyright -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="js/main.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
	Stripe.setPublishableKey('<?php print $publishable_key; ?>');
  
	$(function() {
	  var $form = $('#payment-form');
	  $form.submit(function(event) {
		// Disable the submit button to prevent repeated clicks:
		$form.find('.submit').prop('disabled', true);
	
		// Request a token from Stripe:
		Stripe.card.createToken($form, stripeResponseHandler);
	
		// Prevent the form from being submitted:
		return false;
	  });
	});

	function stripeResponseHandler(status, response) {
	  // Grab the form:
	  var $form = $('#payment-form');
	
	  if (response.error) { // Problem!
	
		// Show the errors on the form:
		$form.find('.payment-errors').text(response.error.message);
		$form.find('.submit').prop('disabled', false); // Re-enable submission
	
	  } else { // Token was created!
	
		// Get the token ID:
		var token = response.id;

		// Insert the token ID into the form so it gets submitted to the server:
		$form.append($('<input type="hidden" name="stripeToken">').val(token));
	
		// Submit the form:
		$form.get(0).submit();
	  }
	};
	
</script>
</footer>
<!-- Footer -->
  </body>
</html>