<!doctype html>
<html lang="en">
 <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Epilogue:wght@300&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

 </head>
  <body >
 
<style type="text/css">
	*{ 
		box-sizing: border-box;
		margin: 0px;
        font-family: 'Epilogue', sans-serif;



	}     .btn-warning {
    color: #ffffff;
    background-color: #ffc107c2;
    border-color: #ffc107;
}
    .btn{
        font-weight:700;
    }
    .btn-outline-primary{
        color:grey;
        border:1px solid grey;
    }
	/* width */
::-webkit-scrollbar {
  width: 8px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
  opacity: 0.5;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
    opacity: 0.5;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
    opacity: 0.5;
}



	body{
		background-color: #fff;
		height:100vh;
		overflow: hidden;
		max-height: 100vh;

	}

	  .cardleft{
	  	box-sizing: border-box;
		position: relative;
		background-color: #fff;
		width: 99vw;
		height: 88vh;
		max-height:89vh; 
		padding: 5px;
		margin: auto;
		overflow-x: hidden;
		overflow-y: auto;
		border: none;

	
	}


	.lgscreenbtn{
		display: none;
	}

	.smallscreenbtn{
		display: inline-flex;
		z-index: 1;
	}

	#outerbox{
	background-color: transparent;
    max-height: 83vh;
    overflow-x: hidden;
    overflow-y: auto;

	}

	#showonmobilescreen{
		display: none;
	}

	.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(2vw + 9px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(3vw + 20px);
		}
			
		
			@media only screen and (max-width: 373px) {
				.smallscreenmargin{
					margin-top: -10px
				}
				.smallscreenmarginlefr{
					margin-left: -30px;
				}

			}


	@media only screen and (min-width: 1021px) {

		#outerbox{
	background-color: transparent;
    max-height: 110vh;
	padding-bottom:2vh;


	}
		
	  .cardleft{
		padding: 10px;
		background-color: #fff;
		margin-left:10vw;
		width: 38vw;
		height: 100vh;
		max-height:600px;
		box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); 
		border-radius:5px;
		overflow-x: hidden;
		overflow-y: auto;
		float: left;

		}

		.lgscreenbtn{
		display: inline-flex;
	}
		.smallscreenbtn{
			display: none;
		}

		.scrollview{
			max-height: 100%;
			overflow-y: auto;
		}


		#crossicon{
			display: none;
		}

		.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(1vw + 0px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(1vw + 1px);
		}
			body{
		background-color: #f4fcff;
		height:100vh;
		overflow: auto;
		max-height: 100vh;
		overflow-x: hidden;

		}

		#showonmobilescreen{
				display: block;
				float:right;
				width:28vw;
				margin-right:21vw;
                box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); 
			}
				
			#showonmobilescreen2{
				display: none;
			}
		
	}

</style>

<!-- Radio button design -->

<style>
/* The checkboxcontainer */
.checkboxcontainer {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.checkboxcontainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;

  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.checkboxcontainer:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.checkboxcontainer input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.checkboxcontainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.checkboxcontainer .checkmark:after {	
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}

.navbar-light .navbar-brand {
    color: orange;
    font-weight: bolder;
}

</style>
<style>
	.navbar-light .navbar-brand {
    color: rgba(0,0,0,.9);
    font-weight: bolder;
}
</style>	

<nav class="navbar  navbar-light bg-light" style="border-bottom: 1px  solid #80808075;height: 8vh;">
  <a class="navbar-brand" href="#">
  	Liza Maid
  </a>
 

</nav>
<form>
	<div class="modal" id="exampleModalCenter" tabindex="-1" role="dialog"
 aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="width:350px; ">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title" style="font-weight:900">Please Verify Your Number</h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="fa fa-times" aria-hidden="true"></i>
        </button>
      </div>
      <div class="modal-body">
      <h6 style="font-weight:900" class="p-2"> Your Mobile Number</h6>
      	<div class="input-group mb-3">
		 
		  <input type="text" id="number"  class="form-control" pattern="\d*" 
		   placeholder="+923065409758" aria-label="Username" aria-describedby="basic-addon1">
		</div>
		 <div id="recaptcha-container"></div>
        <button type="button" class="btn btn-warning m-2" 
         style="width:300px;border-radius:20px; outline: none;color:white;"
		data-toggle="modal" data-target="#exampleModalCenter2"
		class="close" data-dismiss="modal" aria-label="Close"
		onclick="phoneAuth();"
		 >Send Code</button>


       </div>
     
    </div>
  </div>
</div>
</form>

<form>
	<div class="modal" id="exampleModalCenter2" tabindex="-1" role="dialog"
 aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="width:350px; ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" style="font-weight:900">Please Verify Your Number</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="input-group mb-3">
		  
		  <input type="text" class="form-control" pattern="\d*"  id="verificationCode" 
		   placeholder="Varfication Code" aria-label="Username" aria-describedby="basic-addon1">
		</div>
		<button type="button"class="btn btn-warning m-2" 
         style="width:300px;border-radius:20px; outline: none;"  onclick="codeverify();"  >Varify</button>


       </div>
     
    </div>
  </div>
</div>
</form>

		<form method="Get" action="./dayandtime2.html">




	<div id="outerbox" >
		<!-- Here location div -->


		<!-- <div class="locationdiv">
			<div class="row">
				<div class="col-md-12 text-center">
					<i class="fa fa-map-marker" style="font-size: 2rem;margin-top:10px;color:orange;opacity:0.9;  " aria-hidden="true">
						
					</i>
					Dubai Marina, Dubai

				</div>
			</div>
		</div>

		 End location div -->

		<!-- Here page title -->
		<!-- <div class="titlediv">
			<div class="row">
				<div class="col-md-12 text-center mt-3">
				
				<h4>Service detail</h4>

				</div>
			</div>
		</div> --> 
		<!-- End page title -->
        
        <style>
            .btn-primary{
                background:#54caff;
                border:none;
                font-size: 1rem;
   
                
            }
            .btn-primary:hover{
                background:#54caff;
                border:none;
                
            }

            .btn-primary:active{
                background:#54caff;
                border:none;
                
            }


            .btn-outline-primary:hover{
                background:#54caff;
                border:none;
            }
            .btn-outline-primary:active{
                background:#54caff;
                border:none;
            }
         </style>   

		<div class="whole pt-5" >
				
							<div class="cardleft card"  >
					<div class="row">
						<div class="col-md-12 pl-5 p-4">
							<h6 style="font-weight:900 ">Date</h6>
						</div>
						<div  class="col-md-12 pl-5 pl-4 pl-4 pr-4" style="display: flex;justify-content: space-around;max-width:450px; ">
                        <div  class="input-group date" id="datepicker">
								        <input  class="form-control" required id="dateinput" onblur="changetime()" onchange="changetime();" onmouseleave="changetime()" onmouseleave="changetime()"   placeholder="MM/DD/YYYY"/><span class="input-group-append input-group-addon"><span class="input-group-text"><i class="fa fa-calendar"></i></span></span>
								      </div>
						

						</div>
					</div>
					<div class="row">
						<div class="col-md-12 pl-5 p-4">
							<h6 style="font-weight:900 ">Time</h6>
						</div>
						<div class="col-md-12 pl-5 pl-4 pr-4" style="display: flex;justify-content: space-between;max-width:450px; ">
                        
                        <div class="input-group time" id="timepicker">
								        <input class="form-control" onchange="changetime2();" onblur="changetime2()" onmouseleave="changetime2()" onmouseleave="changetime2()"   required id="timeinput" placeholder="HH:MM AM/PM"/><span class="input-group-append input-group-addon"><span class="input-group-text"><i class="fa fa-clock-o"></i></span></span>
								      </div>
								 
						</div>
					</div>
				
						<div class="row lgscreenbtn" style="position: absolute;bottom: 0;border-top: 1px solid grey ;width: 100%;background-color: #fff;">
						<div class="col-md-12 p-3">
							<button id="nextbtn"  type="button"  data-toggle="modal" data-target="#exampleModalCenter" class="btn btn-warning   float-right" style="width:150px;border-radius:20px; outline: none;
							">
								Next
							</button>
						</div>
					</div>
				</div>
				
				<div id="showonmobilescreen">
					
					<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1);border-bottom:3px solid grey; ">

					

						 <div class="card-body" style="border-bottom:1px solid #80808057;display: flex;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Order</h6>
						 	<h6>Detail</h6>
						  </div>
						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
						 	<h6 id="materialchip">Yes</h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
                             <h6 id="dandt"></h6>
                             <span id="time1"></span>
						  </div>
						   </div>
<!-- Herer all rerocd -->
<input  name="location"  value="<?php echo($_GET['location']); ?>" style="display:none;"/>
 <input  name="booking"   value="<?php echo($_GET['booking']); ?>" style="display:none;"/>
 <input  name="cleaner"  value="<?php echo($_GET['cleaner']); ?>" style="display:none;"/>
 <input  name="material"   value="<?php echo($_GET['material']); ?>"style="display:none;"/>
 <input  name="duration"  value="<?php echo($_GET['duration']); ?>" style="display:none;"/>
<!-- end -->

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Address </h6>
						 	<h6><?php echo($_GET['location']) ?></h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   <h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">Price Detail</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Price</h6>
						 	<h6>One</h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6>VAT</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Total</h6>
									   <h6 style="font-weight:900;color:#0b4f65">AED 78.00</h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>
					</div>
				</div>


		</div>




	</div>

	<div id="showonmobilescreen2" style="overflow-y:auto;">
					
					<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					<div id="crossicon"  style="display: flex;justify-content: flex-end;margin:14px;margin-right:30px;  ">
                    <i   onclick="closediv()"  class="fa fa-times" aria-hidden="true">	
                        </i>
                        
					</div>

							<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					

						 <div class="card-body" style="border-bottom:1px solid #80808057;display: flex;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">City</h6>
						 	<h6>Dubai</h6>
						  </div>
						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"><?php echo($_GET['booking']) ?></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6 id="duration"><?php echo($_GET['duration']); ?> hour</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6 id="cleaner"><?php echo($_GET['cleaner']); ?></h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
                                       <h6 id="materialchip"><?php echo($_GET['material']); ?></h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
                             <h6 id="dandt2"></h6>
                             <span id="time2"></span>
						  </div>
						   </div>


						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Address </h6>
						 	<h6><?php echo($_GET['location']) ?></h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">Price Detail</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Price</h6>
						 	<h6>One</h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6>VAT</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Total</h6>
									   <h6 style="font-weight:900;color:#0b4f65">AED 78.00</h6>
						   	</div>
						
						 
						  </div>
						   </div>

						  </div>
					</div>				
					</div>
				</div>
					<style type="text/css">
						#removefocus{
							background: none;
						}
						#removefocus:focus{
							outline: none;
						}
					</style>
					<div class="row smallscreenbtn" 
					style="position: fixed;bottom: 0;border-top: 1px solid grey ;width:102vw;
						background-color: #fff;max-height:100px; 
					">
							<div class="col-md-12 p-3" style="display: flex;justify-content: space-between;">



									<i  onclick="opencar();" class="fa fa-arrow" id="removefocus" style="width:150px;border-radius:20px; padding:5px 4px;
									font-size:24px;color:black;text-align: left; padding-left:2.5rem; 
									outline: none;border:none;

								  ">
									&#xf106;	

								</i>

							<button type="button" id="nextbtn"  data-toggle="modal" data-target="#exampleModalCenter"  class="btn btn-warning   float-right" style="width:150px;border-radius:20px; padding:5px 4px;
							color: white;font-size:18px;
							  ">
								Next
							</button>
						</div>
					</div>

                        <script type="text/javascript">
                        
                    //    document.getElementById("dateinput").onchange = function() {changetime()};
                       // document.getElementById("timeinput").onchange = function() {changetime2()};

                        function changetime() {
                           
                              var x = document.getElementById("dandt");
                              var z = document.getElementById("dandt2");
                                var y = document.getElementById("dateinput");
                                x.innerText=y.value;
                                z.innerText=y.value;
                               
                                }
                                function changetime2() {
                                           
                              var x = document.getElementById("time1");
                             
                              var z = document.getElementById("time2");
                             
                            var y = document.getElementById("timeinput");
                           
                          
                                x.innerHTML = y.value;
                                z.innerText = y.value;
                                    
                                }

							function opencar() {
										
						document.getElementById('showonmobilescreen2').style.display="block";
						document.getElementById('showonmobilescreen2').style.position="absolute";
						document.getElementById('showonmobilescreen2').style.width='100vw';
						document.getElementById('showonmobilescreen2').style.height='100vh';
						document.getElementById('showonmobilescreen2').style.zindex=999;
						document.getElementById('showonmobilescreen2').style.top=0;
						document.getElementById('showonmobilescreen2').style.left=0;
						document.getElementById('crossicon').style.display='inline-flex';

							document.getElementsByClassName("smallscreenbtn")[0].style.display='none';

							}


							function closediv() {
								document.getElementById('showonmobilescreen2').style.display="none";
							document.getElementsByClassName("smallscreenbtn")[0].style.display='block';

							}

						


							function addtime() {
								 
							 	document.getElementsByClassName('time')[0].innerText="One";

							}
							function addtimebiweek() {
								 
							 	document.getElementsByClassName('time')[0].innerText="Bi-weekly";
							}
							function addtimeweek() {
								 
							 	document.getElementsByClassName('time')[0].innerText="Weekly";
							}

						</script>






    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
	<footer class="page-footer font-small cyan darken-3" style="margin-top:120px;background-color: #212529;">
			

								
							
<!-- Footer Elements -->
<div class="container">

  <!-- Grid row-->
  
  <!-- Grid row-->

</div>
<!-- Footer Elements -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <!-- <a href="#" style="color:white;"> Lizamaid.com</a> -->
</div>
<!-- Copyright -->


  <!-- Footer Elements -->
  </form>
  <!-- Copyright -->
  

 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/eonasdan-bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	if (/Mobi/.test(navigator.userAgent)) {
  // if mobile device, use native pickers
  $(".date input").attr("type", "date");
  $(".time input").attr("type", "time");


} else {
  // if desktop device, use DateTimePicker
  $("#datepicker").datetimepicker({
    useCurrent: false,
    format: "L",
    showTodayButton: true,
    icons: {
      next: "fa fa-chevron-right",
      previous: "fa fa-chevron-left",
      today: 'todayText',
    }
  });
  $("#timepicker").datetimepicker({
    format: "LT",
    icons: {
      up: "fa fa-chevron-up",
      down: "fa fa-chevron-down"
    }
  });
}

</script>
  <!-- Copyright -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    <script type="text/javascript">
//     	$('#exampleModalCenter').on('hidden.bs.modal', function () {
//   // Load up a new modal...
// 			  $('#exampleModalCenter2').modal('show')
// 			})
    </script>
    
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#config-web-app -->

<script>
    // Your web app's Firebase configuration
    var firebaseConfig = {
    apiKey: "AIzaSyCFHQgLIvq-V2upHndMo6l63mfB4qwr2aQ",
    authDomain: "react-native-c2890.firebaseapp.com",
    databaseURL: "https://react-native-c2890.firebaseio.com",
    projectId: "react-native-c2890",
    storageBucket: "react-native-c2890.appspot.com",
    messagingSenderId: "860041277569",
    appId: "1:860041277569:web:76f7032ce09b8d6aab5d80",
    measurementId: "G-CXG4GK1PR5"
  };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
</script>
<script>
window.onload=function () {
  render();
};
function render() {
    // window.recaptchaVerifier=new firebase.auth.RecaptchaVerifier('recaptcha-container');
    // recaptchaVerifier.render();

    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', {
  'size': 'invisible',
  'callback': function(response) {
    // reCAPTCHA solved, allow signInWithPhoneNumber.
    recaptchaVerifier.render();
  }
});
}
function phoneAuth() {
    //get the number
    var number=document.getElementById('number').value;
    //phone number authentication function of firebase
    //it takes two parameter first one is number,,,second one is recaptcha

    $(function () {
   $('#exampleModalCenter2').modal(toggle)
});
$(function () {
   $('#exampleModalCenter').modal(toggle)
});


    // $('#exampleModalCenter2').modal('show');
    // //hidden.bs.modal
    // $('#exampleModalCenter').modal('hidden.bs.modal');
    

    alert(number);
    firebase.auth().signInWithPhoneNumber(number,window.recaptchaVerifier).then(function (confirmationResult) {
        //s is in lowercase
        window.confirmationResult=confirmationResult;
        coderesult=confirmationResult;
        console.log(coderesult);
        alert("Message sent");
    }).catch(function (error) {
        alert(error.message);
    });
}
function codeverify() {
    var code=document.getElementById('verificationCode').value;
    coderesult.confirm(code).then(function (result) {
		alert("Successfully registered");
		window.location = "http://localhost/cleaner/stripe_payment_getway_php/";
        var user=result.user;
        console.log(user);
        alert(user);
    }).catch(function (error) {
        alert(error.message);
    });
}

$('form').submit(false);

</script>
</footer>
<!-- Footer -->
  </body>
</html>