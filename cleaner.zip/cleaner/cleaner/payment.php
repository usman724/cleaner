<?php
error_reporting(0);
session_start();
require 'stripe/Stripe.php';
$publishable_key     = "pk_test_51HWlM0Ih3pbcutMOjr7l23eOF3dsMvkr6CywrX0AAeSwUp66GAu21VgbB8Tr9rwN7Up514zAlifzbbWmOkpsOM8u00MNIGDyLt";
$secret_key            = "sk_test_51HWlM0Ih3pbcutMO1quyitiA3V8lvljabBpFNC5rIHt1SxMXjmnompeBy6WmLe6ncIV09pjW9seE3dG24aZLuDWd00OkU9gkg1";

if(isset($_POST['stripeToken'])){
Stripe::setApiKey($secret_key);
$description     = "Invoice #".rand(99999,999999999);
$amount_cents     = 100;
$tokenid        = $_POST['stripeToken'];
try {
$charge         = Stripe_Charge::create(array( 
"amount"         => $amount_cents,
"currency"         => "usd",
"source"         => $tokenid,
"description"     => $description)              
);
        
$id            = $charge['id'];
$amount     = $charge['amount'];
$balance_transaction = $charge['balance_transaction'];
$currency     = $charge['currency'];
$status     = $charge['status'];
$date     = date("Y-m-d H:i:s");
        
$result = "succeeded";
        
/* You can save the above response in DB */
header("location:index.php?id=".$id);
exit;
}catch(Stripe_CardError $e) {            
$error = $e->getMessage();
$result = "declined";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
<form action="" method="post" name="cardpayment" id="payment-form">
<div class="form-group">
<label class="form-label" for="name">Card Holder Name</label>
<input name="holdername" id="name" class="form-input" type="text"  required />
</div>               
<div class="form-group">
<label class="form-label" for="email">Email</label>
<input name="email" id="email" class="form-input" type="email" required />
</div>         
<div class="form-group">
<label class="form-label" for="card">Card Number</label>
<input name="cardnumber" id="card" class="form-input" type="text" maxlength="16" data-stripe="number" required />
</div>
<div class="form-group2">
<label class="form-label" for="password">Expiry Month / Year & CVV</label>
<select name="month" id="month" class="form-input2" data-stripe="exp_month">
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>     
<select name="year" id="year" class="form-input2" data-stripe="exp_year">
<option value="19">2019</option>
<option value="20">2020</option>
<option value="21">2021</option>
<option value="22">2022</option>
<option value="23">2023</option>
<option value="24">2024</option>
<option value="25">2025</option>
<option value="26">2026</option>
<option value="27">2027</option>
<option value="28">2028</option>
<option value="29">2029</option>
<option value="30">2030</option>
</select>
<input name="cvv" id="cvv" class="form-input2" type="text" placeholder="CVV" data-stripe="cvc" required />
</div>
<div class="form-group">
<div class="payment-errors"></div>
</div>
<div class="button-style">
<button class="button login submit">Paynow ($1.00)</button>
</div>
</form>

<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
Stripe.setPublishableKey('YOUR PUBLIC KEY HERE');
$(function() {
   var $form = $('#payment-form');
   $form.submit(function(event) {
   // Disable the submit button to prevent repeated clicks:
   $form.find('.submit').prop('disabled', true);
    
   // Request a token from Stripe:
   Stripe.card.createToken($form, stripeResponseHandler);
    
   // Prevent the form from being submitted:
   return false;
   });
 });
function stripeResponseHandler(status, response) {
  // Grab the form:
  var $form = $('#payment-form');
    
  if (response.error) { // Problem!
    // Show the errors on the form:
    $form.find('.payment-errors').text(response.error.message);
    $form.find('.submit').prop('disabled', false); // Re-enable submission
  }else { // Token was created!
    // Get the token ID:
    var token = response.id;
   // Insert the token ID into the form so it gets submitted to the server:
    $form.append($('<input type="hidden" name="stripeToken">').val(token));
   // Submit the form:
    $form.get(0).submit();
  }
};
</script>
</body>
</html>