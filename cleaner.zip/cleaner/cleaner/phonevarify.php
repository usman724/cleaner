<!doctype html>
<html lang="en">
 <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style type="text/css">
    	textarea:hover, 
input:hover, 
textarea:active, 
input:active, 
textarea:focus, 
input:focus,
button:focus,
button:active,
button:hover,
label:focus,
.btn:active,
.btn.active
{
    outline:0px !important;
    -webkit-appearance:none;
    box-shadow: none !important;
}
    </style>
 </head>
  <body >

  		<!-- Button trigger modal -->
<button type="button" class="btn btn-primary m-5" data-toggle="modal" data-target="#exampleModalCenter">
 Model Phone Number	
</button>

<!-- Modal -->
<form>
	<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
 aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="width:350px; ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Please verify your number</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="input-group mb-3">
		  <div class="input-group-prepend">
		    <span class="input-group-text" style="background-color: #ffffff;" id="basic-addon1">+92</span>
		  </div>
		  <input type="text" id="number"  class="form-control" pattern="\d*" 
		   placeholder="Phone Number" aria-label="Username" aria-describedby="basic-addon1">
		</div>
		 <div id="recaptcha-container"></div>
		<button type="button" class="btn btn-secondary btn-lg btn-block " 
		data-toggle="modal" data-target="#exampleModalCenter2"
		class="close" data-dismiss="modal" aria-label="Close"
		onclick="phoneAuth();"
		 >Send Code</button>


       </div>
     
    </div>
  </div>
</div>
</form>

<form>
	<div class="modal" id="exampleModalCenter2" tabindex="-1" role="dialog"
 aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="width:350px; ">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Please verify your number</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<div class="input-group mb-3">
		  
		  <input type="text" class="form-control" pattern="\d*"  id="verificationCode" 
		   placeholder="Varfication Code" aria-label="Username" aria-describedby="basic-addon1">
		</div>
		<button type="button" class="btn btn-secondary btn-lg btn-block "  onclick="codeverify();"  >Varify</button>


       </div>
     
    </div>
  </div>
</div>
</form>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    <script type="text/javascript">
    	$('#exampleModalCenter').on('hidden.bs.modal', function () {
  // Load up a new modal...
			  $('#exampleModalCenter2').modal('show')
			})
    </script>
    
<!-- The core Firebase JS SDK is always required and must be listed first -->
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#config-web-app -->

<script>
    // Your web app's Firebase configuration
    var firebaseConfig = {
    apiKey: "AIzaSyCFHQgLIvq-V2upHndMo6l63mfB4qwr2aQ",
    authDomain: "react-native-c2890.firebaseapp.com",
    databaseURL: "https://react-native-c2890.firebaseio.com",
    projectId: "react-native-c2890",
    storageBucket: "react-native-c2890.appspot.com",
    messagingSenderId: "860041277569",
    appId: "1:860041277569:web:76f7032ce09b8d6aab5d80",
    measurementId: "G-CXG4GK1PR5"
  };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
</script>
<script>
window.onload=function () {
  render();
};
function render() {
    window.recaptchaVerifier=new firebase.auth.RecaptchaVerifier('recaptcha-container');
    recaptchaVerifier.render();
}
function phoneAuth() {
    //get the number
    var number=document.getElementById('number').value;
    //phone number authentication function of firebase
    //it takes two parameter first one is number,,,second one is recaptcha

    alert(number);
    firebase.auth().signInWithPhoneNumber(number,window.recaptchaVerifier).then(function (confirmationResult) {
        //s is in lowercase
        window.confirmationResult=confirmationResult;
        coderesult=confirmationResult;
        console.log(coderesult);
        alert("Message sent");
    }).catch(function (error) {
        alert(error.message);
    });
}
function codeverify() {
    var code=document.getElementById('verificationCode').value;
    coderesult.confirm(code).then(function (result) {
        alert("Successfully registered");
        var user=result.user;
        console.log(user);
    }).catch(function (error) {
        alert(error.message);
    });
}
</script>
  </body>
</html>