<!doctype html>
<html lang="en">
 <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    <!-- Here new link add -->

    <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: Liza Maid
    Theme URL: https://bootstrapmade.com/Liza Maid-bootstrap-business-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <!-- Here end -->
 </head>
  <body >


<style type="text/css">
	
	@media only screen and (min-width: 1021px) {

		#outer{
		 box-shadow: 0px 3px 19px #00000021; 	
		}
	}

</style>


<!-- Radio button design -->

<style>
	.navbar-light .navbar-brand {
    color: rgba(0,0,0,.9);
    font-weight: bolder;
}
</style>	

<nav class="navbar  navbar-light bg-light" style="border-bottom: 1px  solid #80808075;height: 8vh;">
  <a class="navbar-brand" href="#">
  	Liza Maid
  </a>
 

</nav>

	<div id="outer" class="offset-md-3" style="background-color:#fff;max-width:700px;padding: 80px 10px;margin-top:10%;" >
			
	<form method="Get"  action="./order.php">
		
		<div class="row" style="margin-top:0%; ">
			<div class="offset-5  col-md-5" style="padding-left:6%; ">
				<button   class="btn " style="background-color: #28a745cf; " onclick="getLocation()" >
					<i  style="color: white;font-size:21px; "class="fa fa-map-marker"></i></button>

			</div>
		</div>	
		<div class="row" style="margin-top:10%;padding: 10px; ">
			<div class="  col-md-12" >
				<div class="input-group mb-3">
				<div class="form-group col-md-12">
				  <input type="text" class="form-control" id="demo" name="location" placeholder="Location" required>

				</div>
 
</div>
 <p style="width: 100%;text-align: center;font-weight:600 ">You can add custom address</p>
			</div>

				
		</div>	
			<div class="row">
				<div class="col-md-12 " >
					
						<button 
            
             style="float: right;font-weight:600;padding:5px 25px;background-color: #28a745cf;  " 
						class="btn btn-success mr-3">
							Next
						</button>
			
				</div>
			</div>
	</form>			
	</div>
					
				

	<script type="text/javascript">


function sendparams() {

    var url = "./select.html?id=22"+"2";
   document.getElementById("myform").setAttribute('action', url);
  
  document.getElementById("myform").submit();
}


		
function getLocationown() {
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPositionByOwn, showError);
} else {
    x.value = "Geolocation is not supported by this browser.";
}
}

     var $j = jQuery.noConflict();
function showPositionByOwn(position) {


var lati = position.coords.latitude;

var lagi = position.coords.longitude;




$j.get("http://open.mapquestapi.com/geocoding/v1/reverse?key=Ji69iKjUvOT35bn8zeZPHMD1Oeemmezs&location=" + lati + "," + lagi + "&includeRoadMetadata=true&includeNearestIntersection=true", function (data) {

var arr = Object.values(data);

console.log(arr);
var addresshere = arr[2][0].locations[0].street + " , " + arr[2][0].locations[0].adminArea5Type + " : " + arr[2][0].locations[0].adminArea5 + " , " + arr[2][0].locations[0].adminArea3;

$('#demo').attr('value', addresshere);
//$('.demo2').attr('value', addresshere);
console.log(addresshere);

})
     }
    
function showPosition(position) {

$('#latitude').attr('value', position.coords.latitude);
$('#longitude').attr('value', position.coords.longitude);
///distance 2 is perfect
$.get("http://open.mapquestapi.com/geocoding/v1/reverse?key=Ji69iKjUvOT35bn8zeZPHMD1Oeemmezs&location=" + position.coords.latitude + "," + position.coords.longitude + "&includeRoadMetadata=true&includeNearestIntersection=true", function (data) {

    var arr = Object.values(data);
    var addresshere = arr[2][0].locations[0].street + " , " + arr[2][0].locations[0].adminArea5Type + " : " + arr[2][0].locations[0].adminArea5 + " , " + arr[2][0].locations[0].adminArea3;

    $('#demo').attr('value', addresshere);
     $('#demo2').attr('value', addresshere);
//    console.log(addresshere);

})
     }


                                    function showError(error) {
                                        switch (error.code) {
                                            case error.PERMISSION_DENIED:
                                                x.value = "User denied the request for Geolocation."
                                                break;
                                            case error.POSITION_UNAVAILABLE:
                                                x.value = "Location information is unavailable."
                                                break;
                                            case error.TIMEOUT:
                                                x.value = "The request to get user location timed out."
                                                break;
                                            case error.UNKNOWN_ERROR:
                                                x.value = "An unknown error occurred."
                                                break;
                                        }
                                    }

                                    $j(window).load(function() {
                                        getLocationown();
                                    });
 



	</script>
<footer class="page-footer font-small cyan darken-3" style="margin-top:120px;background-color: #212529;">

<!-- Footer Elements -->
<div class="container">

  <!-- Grid row-->
  
  <!-- Grid row-->

</div>
<!-- Footer Elements -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <!-- <a href="#" style="color:white;"> Lizamaid.com</a> -->
</div>
<!-- Copyright -->

</footer>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>