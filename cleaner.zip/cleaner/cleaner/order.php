<!doctype html>
<html lang="en">
 <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Epilogue:wght@300&display=swap" rel="stylesheet">
 </head>
  <body >
 
<style type="text/css">
	*{ 
		box-sizing: border-box;
		margin: 0px;
	 font-family: 'Epilogue', sans-serif;




	}

    textarea:hover, 
input:hover, 
textarea:active, 
input:active, 
textarea:focus, 
input:focus,
button:focus,
button:active,
button:hover,
label:focus,
.btn:active,
.btn.active
{
    outline:0px !important;
    -webkit-appearance:none;
    box-shadow: none !important;
}
	/* width */
::-webkit-scrollbar {
  width: 8px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1; 
  opacity: 0.5;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #888; 
    opacity: 0.5;

}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
    opacity: 0.5;
}



	body{
		background-color: #fff;
		height:100vh;
		overflow: hidden;
		max-height: 100vh;

	}

	  .cardleft{
	  	box-sizing: border-box;
		position: relative;
		background-color: #fff;
		width: 99vw;
		height: 88vh;
		max-height:89vh; 
		padding: 5px;
		margin: auto;
		overflow-x: hidden;
		overflow-y: auto;
		border: none;

	
	}


	.lgscreenbtn{
		display: none;
	}

	.smallscreenbtn{
		display: inline-flex;
		z-index: 1;
	}

	#outerbox{
	background-color: transparent;
    max-height: 83vh;
    overflow-x: hidden;
    overflow-y: auto;

	}

	#showonmobilescreen{
		display: none;
	}

	.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(2vw + 9px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(3vw + 20px);
		}
			
		
			@media only screen and (max-width: 373px) {
				.smallscreenmargin{
					margin-top: -10px
				}
				.smallscreenmarginlefr{
					margin-left: -30px;
				}

			}


	@media only screen and (min-width: 1021px) {

		#outerbox{
	background-color: transparent;
    max-height: 120vh;
	padding-bottom:2vh;
   
			
	}

	.smallscreenbtn{
		display:none;	
	}	

	#showonmobilescreen2{
		display:none;
	}
	  .cardleft{
		padding: 10px;
		background-color: #fff;
		margin-left:10vw;
		width: 38vw;
		height: 75vh;
		max-height:76vh;
		box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); 
		border-radius:5px;
		max-width:505px;
		overflow-x: hidden;
		overflow-y: auto;
		float: left;

		}

		.lgscreenbtn{
		display: inline-flex;
	}
		.smallscreenbtn{
			display: none;
		}

		.scrollview{
			max-height: 100%;
			overflow-y: auto;
		}


		#crossicon{
			display: none;
		}

		.min {
		  /* demo */
		  /*this your min padding-left*/
		  padding-left: calc(1vw + 0px);
		}

		.max {
		  /* demo */
		  /*this your max padding-left*/
		  padding-left: calc(1vw + 1px);
		}
			body{
		background-color: #f4fcff;
		height:100vh;
		overflow: auto;
		max-height: 100vh;
		overflow-x: hidden;

		}

		#showonmobilescreen{
				display: block;
				float:right;
				width:28vw;
				margin-right:21vw;
				max-width:406px;
			}
				
			#showonmobilescreen2{
				display: none;
			}
		
	}

</style>

<!-- Radio button design -->

<style>
/* The checkboxcontainer */
.checkboxcontainer {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.checkboxcontainer input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;

  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.checkboxcontainer:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.checkboxcontainer input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.checkboxcontainer input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.checkboxcontainer .checkmark:after {	
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}



</style>

<style>
	.navbar-light .navbar-brand {
    color: rgba(0,0,0,.9);
    font-weight: bolder;
}
</style>	

<nav class="navbar  navbar-light bg-light" style="border-bottom: 1px  solid #80808075;height: 8vh;">
  <a class="navbar-brand" href="#">
  	Liza Maid
  </a>
 

</nav>

		
<form method="GET" action="./orders.php">

	<div id="outerbox" >
		<!-- Here location div -->


		<!-- <div class="locationdiv">
			<div class="row">
				<div class="col-md-12 text-center">
					<i class="fa fa-map-marker" style="font-size: 2rem;margin-top:10px;color:orange;opacity:0.9;  " aria-hidden="true">
						
					</i>
					
                           <?php echo($_GET['location']); ?>     
				</div>
			</div>
		</div> -->

		<!-- End location div -->

		<!-- Here page title -->
		<!-- <div class="titlediv">
			<div class="row">
				<div class="col-md-12 text-center mt-3">
				
				<h3>Service detail</h3>

				</div>
			</div>
		</div> -->
		<!-- End page title -->
	
		<div class="whole pt-5" style="max-width:1380px" >
				
				<div class="cardleft card"  >
					<div class=" mt-3">
						<div class="col-md-12">
							<h5>How often do you need your cleaner?</h5>
						</div>
					</div>			

						<div class="row scrollview">
							<div class="col-md-12" style="padding-left:10%;">
									
				
					<div class="row mt-4  mb-2" style="background-color:#fff">
						<label class="checkboxcontainer">
						  <input type="radio"  name="radio"  required value="One"  onclick="addtime();">
						  <span class="checkmark"></span>
						</label>
							<div class="min max smallscreenmarginlefr">
								<h6 style="color:rgb(0,0,0,0.6);">One</h6>
							<p style="color:rgb(0,0,0,0.6);font-size:14px;">Book Cleaning  For One time Only

							</p> 
							</div>
                    </div>
                    
                    <input  name="location"  value="<?php echo($_GET['location']); ?>" style="display:none;"/>
                    <input id="booktime"  name="booking"  style="display:none;"/>
					
						<div class="row mt-4  mb-2" style="background-color:#fff">
						<label class="checkboxcontainer">
						  <input type="radio" required   name="radio" value="Bi-weekly"  onclick="addtimebiweek();">
						  <span class="checkmark"></span>
						</label>
							<div class="min max smallscreenmargin" >
								<h6 style="color:rgb(0,0,0,0.6);">Bi-weekly 
							 <span class="badge badge-warning">
										<i class="fa fa-tag" aria-hidden="true"></i> 5% Off
									</span>
									</h6>
							<p style="color:rgb(0,0,0,0.6);max-width:300px;font-size:14px;">Book a recurring cleaning with the same cleaner every two-weeks
                       </p> 
							</div>
					</div>
					

					<div class="row mt-4  mb-2" style="background-color:#fff; " >
						<label class="checkboxcontainer">
						  <input type="radio" required  name="radio" name="Weekly" onclick="addtimeweek();" >
						  <span class="checkmark"></span>
						</label>
							<div class="min max">
								<h6 style="color:rgb(0,0,0,0.6);">Weekly 
							 <span class="badge badge-warning">
										<i class="fa fa-tag" aria-hidden="true"></i> 12% Off
									</span>
									</h6>
							<p style="color:rgb(0,0,0,0.6);max-width:300px;font-size:14px;">
								Book a recurring cleaning with the same cleaner every week
							</p> 
							</div>
					</div>
						</div>
						</div>
	     <div class="row lgscreenbtn" style="position: absolute;bottom: 0;border-top: 1px solid grey ;width: 100%;background-color: #fff;">
						<div class="col-md-12 p-3">

                        
							<button class="btn btn-warning   float-right" style="width:150px;border-radius:20px; outline: none;
							">
								Next
							</button>
						</div>
					</div>
				</div>
				
				<div id="showonmobilescreen">
					
					<div class="card" style="border:none;box-shadow: 0 1px 5px 0 rgba(0,0,0,.12), 0 3px 1px -2px rgba(0,0,0,.12), 0 2px 2px 0 rgba(0,0,0,.12); ">

					

						 <div class="card-body" style="display: flex;border-bottom:1px solid #80808057;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Order</h6>
						 	<h6>Detail</h6>
						  </div>


						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6> </h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6> </h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
						 	<h6> </h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
						 	<h6></h6>
						  </div>
						   </div>


						   <div style="border-bottom:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Address </h6>
						 	<h6> <?php echo($_GET['location']); ?>     </h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">Price Detail</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Price</h6>
						 	<h6>AED 74.29</h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Vat</h6>
						 	<h6>AED 3.1</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Total</h6>
						 	<h6 style="font-weight:900;color:#0b4f65">AED 78.00</h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>
					</div>
				</div>


		</div>




	</div>

	<div id="showonmobilescreen2" style="overflow-y:auto;">
					
					<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					<div id="crossicon"  style="display: flex;justify-content: flex-end;margin:14px;margin-right:30px;  ">
						
                        <i   onclick="closediv()"  class="fa fa-times" aria-hidden="true">
                    </i> 
						
					</div>

							<div class="card" style="border:none;box-shadow: 4px 4px 9px rgb(0,0,0,0.1); ">

					

						 <div class="card-body" style="border-bottom:1px solid #80808057;display: flex;
						 justify-content: space-between;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Order</h6>
						 	<h6>Detail</h6>
						  </div>
						   <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Frequency</h6>
						 	<h6 class="time"></h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6> </h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Number of Cleaners</h6>
						 	<h6> </h6>
						   	</div>
						 <div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Material</h6>
						 	<h6> </h6>
						   	</div>
						 
						  </div>
						   </div>

						  </div>

						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;flex-wrap: wrap;
						 justify-content: space-between;padding: 15px 15px ;
						 ">
						   

						 	<h6 style="color: #a0b1c0;font-weight:650; ">Date & Time </h6>
						 	<h6></h6>
						  </div>
						   </div>


						   <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 <div class="car" style="display: flex;  flex-wrap: wrap;
						 justify-content: space-between;padding: 15px 15px ;
                         "

                         >
                           
                        


						 	<h6 style="color: #a0b1c0;font-weight:650;">Address </h6>
						 	<h6> <?php echo($_GET['location']); ?>     </h6>
						  </div>
						   </div>
						    <div style="border-bottom:1px solid #80808057;border-top:1px solid #80808057;width:100%; ">
						   	
						 
						   </div>
						     <div class="card-body">
						   <div class="row">
						   		
						   	<h6 class="offset-1" style="color: #a0b1c0;font-weight:650; ">SERVICE DETAILS</h6>
						   </div>
						   <div class="row">
						   <div class="card-body">
						   
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Price</h6>
						 	<h6>One</h6>
						   	</div>
						   	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Duration</h6>
						 	<h6>VAT</h6>
						   	</div>
						 	<div  style="display: flex;
						 justify-content: space-between;">
						   			<h6 style="color: #a0b1c0;font-weight:100; ">Total</h6>
									   <h6 style="font-weight:900;color:#0b4f65">AED 78.00</h6>
						   	</div>
						
						  </div>
						   </div>

						  </div>
					</div>				
					</div>
				</div>
					<style type="text/css">
						#removefocus{
							background: none;
						}
						#removefocus:focus{
							outline: none;
						}
					</style>
					<div class="row smallscreenbtn" 
					style="position: fixed;bottom: 0;border-top: 1px solid grey ;width:102vw;
						background-color: #fff;max-height:100px; 
					">
							<div class="col-md-12 p-3" style="display: flex;justify-content: space-between;">



									<i  onclick="opencar();" class="fa fa-arrow" id="removefocus" style="width:150px;border-radius:20px; padding:5px 4px;
									font-size:24px;color:black;text-align: left; padding-left:2.5rem; 
									outline: none;border:none;

								  ">
									&#xf106;	

								</i>

							<button class="btn btn-warning   float-right" style="width:150px;border-radius:20px; padding:5px 4px;
							color: white;font-size:18px;
							  ">
								Next
							</button>
						</div>
					</div>

						<script type="text/javascript">
							function opencar() {
										
						document.getElementById('showonmobilescreen2').style.display="block";
						document.getElementById('showonmobilescreen2').style.position="absolute";
						document.getElementById('showonmobilescreen2').style.width='100vw';
						document.getElementById('showonmobilescreen2').style.height='100vh';
						document.getElementById('showonmobilescreen2').style.zindex=999;
						document.getElementById('showonmobilescreen2').style.top=0;
						document.getElementById('showonmobilescreen2').style.left=0;
						document.getElementById('crossicon').style.display='inline-flex';

							document.getElementsByClassName("smallscreenbtn")[0].style.display='none';

							}


							function closediv() {
								document.getElementById('showonmobilescreen2').style.display="none";
							document.getElementsByClassName("smallscreenbtn")[0].style.display='block';

							}


							function addtime() {
								 
                                 document.getElementsByClassName('time')[0].innerText="One";
                                 document.getElementById("booktime").setAttribute("value", "One");

							}
							function addtimebiweek() {
								 
                                 document.getElementsByClassName('time')[0].innerText="Bi-weekly";
                                 document.getElementById("booktime").setAttribute("value", "Bi-weekly");
							}
							function addtimeweek() {
								 
                                 document.getElementsByClassName('time')[0].innerText="Weekly";
                                 document.getElementById("booktime").setAttribute("value", "weekly");

							}

						</script>






    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <!-- Footer -->
	<footer class="page-footer font-small cyan darken-3" style="margin-top:120px;background-color: #212529;">

<!-- Footer Elements -->
<div class="container">

  <!-- Grid row-->
  
  <!-- Grid row-->

</div>
<!-- Footer Elements -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <!-- <a href="#" style="color:white;"> Lizamaid.com</a> -->
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->
</form>
  </body>
</html>